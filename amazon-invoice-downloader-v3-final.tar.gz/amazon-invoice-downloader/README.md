# Amazon Invoice Downloader

Automatisierter Download von Amazon-Rechnungen mit Brave Browser für CachyOS.

## 🎯 Features

- ✅ Automatischer Download aller Amazon-Rechnungen
- ✅ Filterung nach Jahr möglich
- ✅ Nutzt dein bestehendes Brave-Browser-Profil (bleibst eingeloggt)
- ✅ Überspringt bereits heruntergeladene Rechnungen
- ✅ Saubere Dateinamen: `Amazon_Rechnung_XXX-XXXXXXX-XXXXXXX.pdf`
- ✅ Konfigurierbar über YAML-Datei

## 📋 Voraussetzungen

- CachyOS (Arch-basiert)
- Brave Browser installiert
- Python 3.x

## 🚀 Installation

```bash
# 1. Installer ausführbar machen
chmod +x install.sh

# 2. Installation starten
./install.sh

# 3. PATH aktualisieren (wenn nötig)
source ~/.bashrc
```

Die Installation installiert automatisch:
- Python, pip, Chromium
- Selenium und Dependencies
- Wrapper-Skript `amazon-invoices`

## ⚙️ Konfiguration

Die Konfiguration befindet sich hier:
```
~/.local/share/amazon-invoice-downloader/config.yaml
```

### Wichtige Einstellungen:

```yaml
browser:
  brave_path: "/usr/bin/brave"          # Pfad zu Brave
  use_profile: true                      # Nutze bestehendes Profil
  profile_path: "~/.config/BraveSoftware/Brave-Browser"
  profile_name: "Default"                # Oder "Profile 1", etc.
  headless: false                        # Beim ersten Login: false!

download:
  directory: "~/Dokumente/Amazon-Rechnungen"  # Download-Verzeichnis
  delay_seconds: 2                       # Pause zwischen Downloads
```

### Brave-Profil herausfinden:

```bash
# Liste alle Profile auf
ls ~/.config/BraveSoftware/Brave-Browser/

# Übliche Profile:
# - Default (Standard-Profil)
# - Profile 1, Profile 2, etc. (zusätzliche Profile)
```

## 📖 Verwendung

### Alle Rechnungen herunterladen:

```bash
amazon-invoices --download-all
```

### Nur Rechnungen eines Jahres:

```bash
amazon-invoices --year 2024
amazon-invoices --year 2023
```

### Mit eigener Konfiguration:

```bash
amazon-invoices --download-all --config /pfad/zu/config.yaml
```

### Hilfe anzeigen:

```bash
amazon-invoices --help
```

## 🔒 Sicherheitsüberwachung

Der integrierte **Security Monitor** überwacht in Echtzeit die Netzwerk-Aktivität während das Download-Skript läuft.

### Empfohlener Workflow (2 Terminals):

**Terminal 1 - Security Monitor:**
```bash
amazon-security-monitor
```

**Terminal 2 - Download:**
```bash
amazon-invoices --download-all
```

### Was überwacht der Security Monitor:

✅ **Lauschende Python-Ports** (sollten KEINE existieren)  
✅ **Ausgehende Verbindungen** (nur zu Amazon erwartet)  
✅ **Browser-Prozesse** (Brave/ChromeDriver)  
✅ **Prozess-Aktivität** (Python-Skript)

### Security Monitor Modi:

```bash
# Kontinuierliche Überwachung (alle 5 Sek.)
amazon-security-monitor

# Einmalige Prüfung
amazon-security-monitor check
```

### Erwartete Ausgabe (SICHER):

```
✓ Keine lauschenden Python-Ports gefunden (sicher)
✓ Keine aktiven Python-Verbindungen
  Brave:        5 Prozesse
  ChromeDriver: 1 Prozesse
  Python (DL):  1 Prozesse
```

### Warnsignale (UNSICHER):

```
⚠ WARNUNG: Python lauscht auf Ports!
tcp    0.0.0.0:8080    LISTEN    12345/python
```

**→ Bei solchen Warnungen:** Download sofort abbrechen und Skript überprüfen!

## 🔐 Erster Start / Login

Beim **ersten Start** musst du dich manuell einloggen:

```bash
# Starte mit sichtbarem Browser (headless: false in config.yaml)
amazon-invoices --download-all
```

Das Skript:
1. Öffnet Brave Browser
2. Navigiert zu Amazon
3. Wartet auf deinen manuellen Login
4. Nach dem Login: Drücke ENTER im Terminal
5. Der Download startet automatisch

**Wichtig:** Nach dem ersten Login bleibst du durch das Brave-Profil eingeloggt und musst dich nicht erneut anmelden!

## 📁 Verzeichnisstruktur

```
~/.local/share/amazon-invoice-downloader/
├── amazon_invoice_downloader.py    # Hauptskript
└── config.yaml                     # Konfiguration

~/.local/bin/
└── amazon-invoices                 # Wrapper-Skript (im PATH)

~/.venv/selenium/                   # Python Virtual Environment
└── lib/python3.x/site-packages/    # Selenium und Dependencies

~/Dokumente/Amazon-Rechnungen/      # Download-Verzeichnis (konfigurierbar)
└── Amazon_Rechnung_*.pdf           # Heruntergeladene Rechnungen
```

## 🐛 Troubleshooting

### Browser startet nicht:

```bash
# Prüfe ob Brave installiert ist
which brave

# Falls nicht gefunden, installiere Brave
yay -S brave-bin
```

### ChromeDriver-Fehler:

```bash
# ChromeDriver ist in Chromium enthalten
sudo pacman -S chromium

# Version prüfen
chromedriver --version
```

### Login funktioniert nicht:

1. Prüfe ob `use_profile: true` in der config.yaml gesetzt ist
2. Stelle sicher, dass du im Brave-Profil bei Amazon eingeloggt bist
3. Verwende beim ersten Start `headless: false`

### Rechnungen werden nicht gefunden:

- Amazon zeigt nicht für alle Bestellungen Rechnungen an (z.B. Marketplace-Verkäufer)
- Prüfe manuell ob Rechnungen in deinem Amazon-Konto vorhanden sind

### "Virtual Environment nicht gefunden":

```bash
# Installer erneut ausführen
./install.sh
```

## 🔧 Entwicklung & Anpassung

### Manuell starten (für Debugging):

```bash
# Virtual Environment aktivieren
source ~/.venv/selenium/bin/activate

# Skript direkt ausführen
python ~/.local/share/amazon-invoice-downloader/amazon_invoice_downloader.py --download-all
```

### Logs anzeigen:

Das Skript gibt detaillierte Ausgaben im Terminal aus. Bei Fehlern werden diese direkt angezeigt.

### Skript anpassen:

```bash
nano ~/.local/share/amazon-invoice-downloader/amazon_invoice_downloader.py
```

## ⚠️ Wichtige Hinweise

### Rechtliches:

- Dieses Tool ist für den **privaten Gebrauch** gedacht
- Automatisiertes Scraping verstößt technisch gegen Amazon's AGBs
- Für private Nutzung wird dies selten verfolgt
- **Nutze das Tool verantwortungsvoll** und nicht kommerziell

### Sicherheit:

- Das Tool nutzt dein bestehendes Brave-Profil
- **Keine Passwörter werden gespeichert oder übertragen**
- Alle Login-Daten bleiben in deinem Brave-Browser
- Das Skript läuft komplett lokal auf deinem System

### Performance:

- Zwischen Downloads werden automatische Pausen eingelegt (`delay_seconds`)
- Zu häufige Anfragen können als Bot-Aktivität erkannt werden
- Empfohlene Pause: mindestens 2 Sekunden

## 📊 Beispiel-Ausgabe

```
==================================================
Amazon Invoice Downloader
==================================================

✓ Browser gestartet
✓ Bereits eingeloggt

🔍 Suche Bestellungen für 2024...

📄 Verarbeite Seite 1...
  ✓ Gefunden: 302-1234567-8901234
  ✓ Gefunden: 302-2345678-9012345
  ...

✓ Alle Seiten verarbeitet

✓ 24 Bestellungen mit Rechnungen gefunden

📥 Starte Download nach: /home/danny/Dokumente/Amazon-Rechnungen

[1/24] 302-1234567-8901234
  ✓ Heruntergeladen

[2/24] 302-2345678-9012345
  ⏭ Bereits vorhanden

...

==================================================
✓ Erfolgreich: 24
❌ Fehlgeschlagen: 0
📁 Speicherort: /home/danny/Dokumente/Amazon-Rechnungen
==================================================

✓ Browser geschlossen
```

## 🤝 Support

Bei Problemen oder Fragen:
1. Prüfe die Troubleshooting-Sektion
2. Überprüfe die config.yaml
3. Schaue in die Terminal-Ausgabe für Fehlermeldungen

## 📝 Lizenz

Dieses Tool wurde für private Zwecke entwickelt.

## 🔄 Git Repository Setup

Wenn du dieses Projekt in einem Git-Repository verwalten möchtest:

### Automatisches Setup:

```bash
./git-setup.sh
```

Das Skript:
- ✅ Initialisiert Git-Repository
- ✅ Installiert Pre-commit Hook (verhindert versehentliches Committen sensibler Daten)
- ✅ Erstellt Initial Commit
- ✅ Prüft auf Sicherheitsprobleme

### Manuelles Setup:

```bash
# Git initialisieren
git init

# Pre-commit Hook installieren (empfohlen!)
cp scripts/pre-commit.sh .git/hooks/pre-commit
chmod +x .git/hooks/pre-commit

# Dateien hinzufügen
git add .

# Commit
git commit -m "Initial commit"

# Remote hinzufügen
git remote add origin <URL>
git push -u origin main
```

### ⚠️ Wichtig - .gitignore:

Die `.gitignore` ist so konfiguriert, dass **KEINE** sensiblen Daten hochgeladen werden:

- ❌ `config/config.yaml` (persönliche Pfade)
- ❌ `**/*Rechnung*.pdf` (persönliche Rechnungen)
- ❌ `.venv/` (Virtual Environment)
- ❌ Browser-Profile (Login-Daten)

**Nur hochgeladen werden:** Quellcode, Dokumentation, Templates

Siehe `GIT-SETUP.txt` für Details.

---

**Erstellt für:** Danny (yDh-embedded)  
**System:** CachyOS  
**Datum:** Januar 2026
