#!/bin/bash
# Git Repository Setup für Amazon Invoice Downloader
# Richtet Git mit Sicherheitsmaßnahmen ein

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Farben
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔═══════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║  Git Repository Setup                        ║${NC}"
echo -e "${BLUE}║  Amazon Invoice Downloader                   ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════╝${NC}"
echo

# Prüfe ob git installiert ist
if ! command -v git &> /dev/null; then
    echo -e "${RED}❌ Git ist nicht installiert!${NC}"
    echo "Installation: sudo pacman -S git"
    exit 1
fi

# Prüfe ob bereits ein Git-Repo existiert
if [ -d ".git" ]; then
    echo -e "${YELLOW}⚠ Git-Repository existiert bereits!${NC}"
    read -p "Neu initialisieren? (löscht .git) (j/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Jj]$ ]]; then
        rm -rf .git
        echo -e "${GREEN}✓ Altes Repository gelöscht${NC}"
    else
        echo "Abgebrochen."
        exit 0
    fi
fi

# 1. Git initialisieren
echo -e "${YELLOW}[1/6] Initialisiere Git Repository...${NC}"
git init
echo -e "${GREEN}✓ Git Repository initialisiert${NC}"

# 2. .gitignore prüfen
echo -e "${YELLOW}[2/6] Prüfe .gitignore...${NC}"
if [ ! -f ".gitignore" ]; then
    echo -e "${RED}❌ .gitignore fehlt!${NC}"
    exit 1
fi
echo -e "${GREEN}✓ .gitignore vorhanden${NC}"

# 3. config.yaml.example erstellen falls nicht vorhanden
echo -e "${YELLOW}[3/6] Prüfe config.yaml.example...${NC}"
if [ ! -f "config/config.yaml.example" ]; then
    if [ -f "config/config.yaml" ]; then
        cp config/config.yaml config/config.yaml.example
        echo -e "${GREEN}✓ config.yaml.example erstellt${NC}"
    else
        echo -e "${YELLOW}⚠ Keine config.yaml gefunden - überspringe${NC}"
    fi
else
    echo -e "${GREEN}✓ config.yaml.example vorhanden${NC}"
fi

# 4. Pre-commit Hook installieren
echo -e "${YELLOW}[4/6] Installiere Pre-commit Hook...${NC}"
if [ -f "scripts/pre-commit.sh" ]; then
    mkdir -p .git/hooks
    cp scripts/pre-commit.sh .git/hooks/pre-commit
    chmod +x .git/hooks/pre-commit
    echo -e "${GREEN}✓ Pre-commit Hook installiert${NC}"
else
    echo -e "${YELLOW}⚠ pre-commit.sh nicht gefunden - überspringe${NC}"
fi

# 5. Git-Konfiguration
echo -e "${YELLOW}[5/6] Konfiguriere Git...${NC}"

# User-Name prüfen
if [ -z "$(git config user.name)" ]; then
    echo -e "${YELLOW}Git User-Name nicht gesetzt.${NC}"
    read -p "Dein Name: " GIT_NAME
    git config user.name "$GIT_NAME"
fi

# User-Email prüfen
if [ -z "$(git config user.email)" ]; then
    echo -e "${YELLOW}Git User-Email nicht gesetzt.${NC}"
    read -p "Deine Email: " GIT_EMAIL
    git config user.email "$GIT_EMAIL"
fi

# Default Branch auf main setzen
git config init.defaultBranch main

echo -e "${GREEN}✓ Git konfiguriert${NC}"
echo "  Name:  $(git config user.name)"
echo "  Email: $(git config user.email)"

# 6. Initial Commit
echo -e "${YELLOW}[6/6] Erstelle Initial Commit...${NC}"

# Dateien hinzufügen
git add .

# Status zeigen
echo
echo -e "${BLUE}Folgende Dateien werden committed:${NC}"
git status --short

# Sicherheitscheck
echo
echo -e "${YELLOW}Sicherheits-Check:${NC}"
ISSUES=0

# Prüfe ob config.yaml committed wird
if git status --short | grep -q "config/config.yaml$"; then
    echo -e "${RED}❌ config.yaml wird committed - SOLLTE NICHT PASSIEREN!${NC}"
    ISSUES=$((ISSUES + 1))
else
    echo -e "${GREEN}✓ config.yaml wird nicht committed${NC}"
fi

# Prüfe ob PDFs committed werden
if git status --short | grep -qi "\.pdf$"; then
    echo -e "${RED}❌ PDF-Dateien werden committed - SOLLTE NICHT PASSIEREN!${NC}"
    ISSUES=$((ISSUES + 1))
else
    echo -e "${GREEN}✓ Keine PDF-Dateien werden committed${NC}"
fi

# Prüfe ob .venv committed wird
if git status --short | grep -q "\.venv/"; then
    echo -e "${RED}❌ .venv wird committed - SOLLTE NICHT PASSIEREN!${NC}"
    ISSUES=$((ISSUES + 1))
else
    echo -e "${GREEN}✓ .venv wird nicht committed${NC}"
fi

if [ $ISSUES -gt 0 ]; then
    echo
    echo -e "${RED}═══════════════════════════════════════════════${NC}"
    echo -e "${RED}❌ Sicherheitsprobleme gefunden!${NC}"
    echo -e "${RED}═══════════════════════════════════════════════${NC}"
    echo "Bitte .gitignore überprüfen und git reset durchführen."
    exit 1
fi

# Commit erstellen
echo
read -p "Initial Commit erstellen? (j/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Jj]$ ]]; then
    git commit -m "Initial commit: Amazon Invoice Downloader

- Automatischer Download von Amazon-Rechnungen
- Integrierter Security Monitor
- Brave Browser Integration
- Konfigurierbar über YAML"
    echo -e "${GREEN}✓ Initial Commit erstellt${NC}"
else
    echo -e "${YELLOW}Commit übersprungen${NC}"
fi

# Zusammenfassung
echo
echo -e "${GREEN}╔═══════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║  ✓ Git Repository erfolgreich eingerichtet   ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════════════╝${NC}"
echo
echo -e "${YELLOW}Nächste Schritte:${NC}"
echo
echo "1. Remote Repository hinzufügen:"
echo -e "   ${BLUE}git remote add origin <URL>${NC}"
echo
echo "2. Push durchführen:"
echo -e "   ${BLUE}git push -u origin main${NC}"
echo
echo "3. Oder auf GitHub/GitLab erstellen und dann:"
echo -e "   ${BLUE}git remote add origin https://github.com/USERNAME/amazon-invoice-downloader.git${NC}"
echo -e "   ${BLUE}git push -u origin main${NC}"
echo
echo -e "${YELLOW}Wichtige Befehle:${NC}"
echo "  git status          - Zeige Status"
echo "  git log             - Zeige Commits"
echo "  git diff            - Zeige Änderungen"
echo "  git add .           - Alle Änderungen hinzufügen"
echo "  git commit -m 'msg' - Commit erstellen"
echo "  git push            - Zum Remote pushen"
echo
echo -e "${BLUE}Der Pre-commit Hook schützt vor versehentlichem${NC}"
echo -e "${BLUE}Committen sensibler Daten!${NC}"
