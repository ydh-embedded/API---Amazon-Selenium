#!/bin/bash
# Amazon Invoice Downloader - Hauptinstaller
# Für CachyOS mit Brave Browser
# Erstellt für: Danny (yDh-embedded)

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="$HOME/.local/share/amazon-invoice-downloader"
VENV_DIR="$HOME/.venv/selenium"

# Farben
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}"
cat << "EOF"
╔═══════════════════════════════════════════════╗
║  Amazon Invoice Downloader - Installer       ║
║  Für CachyOS mit Brave Browser               ║
╚═══════════════════════════════════════════════╝
EOF
echo -e "${NC}"

# Root-Check
if [[ $EUID -eq 0 ]]; then
   echo -e "${RED}❌ Bitte NICHT als root ausführen!${NC}"
   exit 1
fi

# 1. System-Pakete installieren
echo -e "${YELLOW}[1/5] Installiere System-Pakete...${NC}"
sudo pacman -S --needed --noconfirm python python-pip chromium

# 2. Virtual Environment erstellen
echo -e "${YELLOW}[2/5] Erstelle Virtual Environment...${NC}"
if [ ! -d "$VENV_DIR" ]; then
    python -m venv "$VENV_DIR"
    echo -e "${GREEN}✓ Virtual Environment erstellt${NC}"
else
    echo -e "${GREEN}✓ Virtual Environment existiert bereits${NC}"
fi

# 3. Python-Pakete installieren
echo -e "${YELLOW}[3/5] Installiere Python-Pakete...${NC}"
source "$VENV_DIR/bin/activate"
pip install --upgrade pip --quiet
pip install selenium webdriver-manager pyyaml --quiet

# 4. Skripte installieren
echo -e "${YELLOW}[4/5] Installiere Downloader-Skripte...${NC}"
mkdir -p "$INSTALL_DIR"
cp "$SCRIPT_DIR/scripts/amazon_invoice_downloader.py" "$INSTALL_DIR/"
cp "$SCRIPT_DIR/scripts/security_monitor.sh" "$INSTALL_DIR/"
cp "$SCRIPT_DIR/config/config.yaml" "$INSTALL_DIR/"
chmod +x "$INSTALL_DIR/amazon_invoice_downloader.py"
chmod +x "$INSTALL_DIR/security_monitor.sh"
echo -e "${GREEN}✓ Skripte nach $INSTALL_DIR kopiert${NC}"

# net-tools für Security Monitor installieren
echo -e "${YELLOW}   Installiere net-tools für Sicherheitsüberwachung...${NC}"
sudo pacman -S --needed --noconfirm net-tools 2>/dev/null || echo "   (net-tools bereits installiert)"

# 5. Wrapper-Skript und Alias erstellen
echo -e "${YELLOW}[5/5] Erstelle Wrapper-Skripte...${NC}"

# Hauptwrapper für amazon-invoices
cat > "$HOME/.local/bin/amazon-invoices" << 'WRAPPER_EOF'
#!/bin/bash
VENV_DIR="$HOME/.venv/selenium"
INSTALL_DIR="$HOME/.local/share/amazon-invoice-downloader"

if [ ! -d "$VENV_DIR" ]; then
    echo "❌ Virtual Environment nicht gefunden!"
    echo "Bitte führe den Installer erneut aus."
    exit 1
fi

source "$VENV_DIR/bin/activate"
python "$INSTALL_DIR/amazon_invoice_downloader.py" "$@"
WRAPPER_EOF

chmod +x "$HOME/.local/bin/amazon-invoices"

# Security Monitor Wrapper
cat > "$HOME/.local/bin/amazon-security-monitor" << 'MONITOR_WRAPPER_EOF'
#!/bin/bash
INSTALL_DIR="$HOME/.local/share/amazon-invoice-downloader"

if [ ! -f "$INSTALL_DIR/security_monitor.sh" ]; then
    echo "❌ Security Monitor nicht gefunden!"
    echo "Bitte führe den Installer erneut aus."
    exit 1
fi

exec "$INSTALL_DIR/security_monitor.sh" "$@"
MONITOR_WRAPPER_EOF

chmod +x "$HOME/.local/bin/amazon-security-monitor"

echo -e "${GREEN}✓ Wrapper-Skripte erstellt${NC}"

# PATH-Check und Update
if [[ ":$PATH:" != *":$HOME/.local/bin:"* ]]; then
    echo "" >> ~/.bashrc
    echo "# Amazon Invoice Downloader" >> ~/.bashrc
    echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
    echo -e "${YELLOW}⚠ PATH wurde aktualisiert. Bitte neu einloggen oder ausführen:${NC}"
    echo -e "   ${BLUE}source ~/.bashrc${NC}"
fi

# Installations-Info
echo
echo -e "${GREEN}╔═══════════════════════════════════════════════╗"
echo -e "║        ✓ Installation erfolgreich!           ║"
echo -e "╚═══════════════════════════════════════════════╝${NC}"
echo
echo -e "${YELLOW}Installierte Komponenten:${NC}"
echo "  • Python:       $(python --version)"
echo "  • Selenium:     $(pip show selenium | grep Version | cut -d' ' -f2)"
echo "  • ChromeDriver: $(chromedriver --version)"
echo
echo -e "${YELLOW}Installationsverzeichnis:${NC}"
echo "  $INSTALL_DIR"
echo
echo -e "${YELLOW}Konfiguration anpassen:${NC}"
echo "  nano $INSTALL_DIR/config.yaml"
echo
echo -e "${YELLOW}Verwendung:${NC}"
echo "  amazon-invoices --help"
echo "  amazon-invoices --year 2024"
echo "  amazon-invoices --download-all"
echo
echo -e "${YELLOW}Sicherheitsüberwachung:${NC}"
echo "  amazon-security-monitor          # Kontinuierliche Überwachung"
echo "  amazon-security-monitor check    # Einmalige Prüfung"
echo
echo -e "${BLUE}Tipp: Starte den Security Monitor in einem separaten Terminal${NC}"
echo -e "${BLUE}während der Download läuft, um die Netzwerk-Aktivität zu${NC}"
echo -e "${BLUE}überwachen und sicherzustellen, dass keine Ports geöffnet werden.${NC}"
echo
echo -e "${GREEN}Empfohlener Workflow:${NC}"
echo "  Terminal 1: amazon-security-monitor"
echo "  Terminal 2: amazon-invoices --download-all"
