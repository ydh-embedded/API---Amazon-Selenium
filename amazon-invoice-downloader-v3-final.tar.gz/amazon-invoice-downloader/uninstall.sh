#!/bin/bash
# Amazon Invoice Downloader - Deinstallation
# Entfernt alle installierten Komponenten

INSTALL_DIR="$HOME/.local/share/amazon-invoice-downloader"
VENV_DIR="$HOME/.venv/selenium"
WRAPPER_SCRIPT="$HOME/.local/bin/amazon-invoices"

# Farben
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}Amazon Invoice Downloader - Deinstallation${NC}"
echo

# Bestätigung
read -p "Wirklich deinstallieren? (j/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Jj]$ ]]; then
    echo "Abgebrochen."
    exit 0
fi

# Download-Verzeichnis behalten?
echo
echo -e "${YELLOW}Heruntergeladene Rechnungen behalten?${NC}"
read -p "Download-Verzeichnis NICHT löschen? (j/n) " -n 1 -r
echo
KEEP_DOWNLOADS=$REPLY

# Deinstallation
echo
echo "Deinstalliere Komponenten..."

# 1. Installationsverzeichnis
if [ -d "$INSTALL_DIR" ]; then
    rm -rf "$INSTALL_DIR"
    echo -e "${GREEN}✓ Installationsverzeichnis entfernt${NC}"
fi

# 2. Virtual Environment
if [ -d "$VENV_DIR" ]; then
    echo -e "${YELLOW}Virtual Environment löschen?${NC}"
    echo "  (Wird möglicherweise von anderen Projekten genutzt)"
    read -p "Virtual Environment löschen? (j/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Jj]$ ]]; then
        rm -rf "$VENV_DIR"
        echo -e "${GREEN}✓ Virtual Environment entfernt${NC}"
    else
        echo -e "${YELLOW}⏭ Virtual Environment behalten${NC}"
    fi
fi

# 3. Wrapper-Skript
if [ -f "$WRAPPER_SCRIPT" ]; then
    rm "$WRAPPER_SCRIPT"
    echo -e "${GREEN}✓ Wrapper-Skript entfernt${NC}"
fi

# 4. Bashrc-Einträge entfernen
if grep -q "Amazon Invoice Downloader" ~/.bashrc; then
    sed -i '/# Amazon Invoice Downloader/,+1d' ~/.bashrc
    echo -e "${GREEN}✓ Bashrc-Einträge entfernt${NC}"
fi

# 5. Download-Verzeichnis (optional)
if [[ ! $KEEP_DOWNLOADS =~ ^[Jj]$ ]]; then
    # Download-Verzeichnis aus config.yaml auslesen (falls noch vorhanden)
    DOWNLOAD_DIR="$HOME/Dokumente/Amazon-Rechnungen"
    if [ -d "$DOWNLOAD_DIR" ]; then
        echo
        echo -e "${RED}WARNUNG: Lösche Download-Verzeichnis:${NC}"
        echo "  $DOWNLOAD_DIR"
        read -p "Wirklich löschen? (j/n) " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Jj]$ ]]; then
            rm -rf "$DOWNLOAD_DIR"
            echo -e "${GREEN}✓ Download-Verzeichnis entfernt${NC}"
        fi
    fi
fi

echo
echo -e "${GREEN}✓ Deinstallation abgeschlossen${NC}"
echo
echo "Optional: System-Pakete manuell entfernen:"
echo "  sudo pacman -Rs python python-pip chromium"
