#!/bin/bash
# Pre-commit Hook für Amazon Invoice Downloader
# Verhindert versehentliches Committen sensibler Daten
#
# Installation:
# cp scripts/pre-commit.sh .git/hooks/pre-commit
# chmod +x .git/hooks/pre-commit

# Farben
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}🔍 Pre-commit Security Check...${NC}"

ERRORS=0

# 1. Prüfe auf config.yaml
if git diff --cached --name-only | grep -q "config/config.yaml$"; then
    echo -e "${RED}❌ FEHLER: config.yaml sollte NICHT committed werden!${NC}"
    echo "   Diese Datei enthält persönliche Pfade und Einstellungen."
    echo "   Verwende stattdessen: config.yaml.example"
    ERRORS=$((ERRORS + 1))
fi

# 2. Prüfe auf PDF-Dateien (Rechnungen)
if git diff --cached --name-only | grep -qi "\.pdf$"; then
    echo -e "${RED}❌ FEHLER: PDF-Dateien sollten NICHT committed werden!${NC}"
    echo "   Rechnungen enthalten persönliche Daten!"
    ERRORS=$((ERRORS + 1))
fi

# 3. Prüfe auf Virtual Environment
if git diff --cached --name-only | grep -q "\.venv/\|venv/\|env/"; then
    echo -e "${RED}❌ FEHLER: Virtual Environment sollte NICHT committed werden!${NC}"
    echo "   .venv/ ist in .gitignore und sollte lokal bleiben."
    ERRORS=$((ERRORS + 1))
fi

# 4. Prüfe auf Browser-Profile
if git diff --cached --name-only | grep -qi "BraveSoftware\|chromium\|\.mozilla"; then
    echo -e "${RED}❌ FEHLER: Browser-Profile sollten NICHT committed werden!${NC}"
    echo "   Diese enthalten Login-Daten und Cookies!"
    ERRORS=$((ERRORS + 1))
fi

# 5. Prüfe auf __pycache__
if git diff --cached --name-only | grep -q "__pycache__"; then
    echo -e "${RED}❌ FEHLER: __pycache__ sollte NICHT committed werden!${NC}"
    echo "   Python Cache-Dateien sind in .gitignore."
    ERRORS=$((ERRORS + 1))
fi

# 6. Prüfe auf potenzielle Secrets/Credentials
if git diff --cached --name-only | grep -qi "secret\|credential\|password\|\.key\|\.pem"; then
    echo -e "${RED}⚠ WARNUNG: Datei mit potenziellem Secret gefunden!${NC}"
    git diff --cached --name-only | grep -i "secret\|credential\|password\|\.key\|\.pem"
    echo -e "${YELLOW}Bist du sicher, dass diese Dateien committed werden sollen?${NC}"
    read -p "Fortfahren? (j/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Jj]$ ]]; then
        ERRORS=$((ERRORS + 1))
    fi
fi

# 7. Prüfe auf .env Dateien
if git diff --cached --name-only | grep -q "\.env$"; then
    echo -e "${RED}❌ FEHLER: .env Dateien sollten NICHT committed werden!${NC}"
    echo "   Environment-Dateien können Secrets enthalten."
    ERRORS=$((ERRORS + 1))
fi

# 8. Prüfe auf Log-Dateien
if git diff --cached --name-only | grep -q "\.log$"; then
    echo -e "${YELLOW}⚠ WARNUNG: Log-Dateien gefunden.${NC}"
    echo "   Log-Dateien sollten normalerweise nicht committed werden."
fi

# Ergebnis
if [ $ERRORS -gt 0 ]; then
    echo
    echo -e "${RED}═══════════════════════════════════════════════${NC}"
    echo -e "${RED}❌ Commit abgebrochen! $ERRORS Fehler gefunden.${NC}"
    echo -e "${RED}═══════════════════════════════════════════════${NC}"
    echo
    echo "Behebe die Fehler und versuche es erneut."
    echo "Oder nutze 'git commit --no-verify' um diese Prüfung zu überspringen."
    echo "(NICHT empfohlen!)"
    exit 1
else
    echo -e "${GREEN}✓ Alle Security Checks bestanden!${NC}"
    exit 0
fi
