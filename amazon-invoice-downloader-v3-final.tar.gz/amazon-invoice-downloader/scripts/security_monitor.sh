#!/bin/bash
# Security Monitor für Amazon Invoice Downloader
# Überwacht Netzwerk-Aktivität während das Skript läuft

# Farben
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

# PID-Datei für Cleanup
MONITOR_PID_FILE="/tmp/amazon-invoice-monitor.pid"

echo -e "${BLUE}╔════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║  Security Monitor - Amazon Invoice DL     ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════╝${NC}"
echo

# Check ob netstat/ss verfügbar ist
if ! command -v netstat &> /dev/null && ! command -v ss &> /dev/null; then
    echo -e "${RED}❌ Weder 'netstat' noch 'ss' gefunden!${NC}"
    echo "Installation: sudo pacman -S net-tools"
    exit 1
fi

# Funktion: Prüfe Python-Verbindungen
check_python_connections() {
    echo -e "${YELLOW}[$(date +%H:%M:%S)] Prüfe Python-Verbindungen...${NC}"
    
    if command -v netstat &> /dev/null; then
        # Mit netstat
        CONNECTIONS=$(sudo netstat -tulpn 2>/dev/null | grep python)
    else
        # Mit ss (moderner)
        CONNECTIONS=$(sudo ss -tulpn 2>/dev/null | grep python)
    fi
    
    if [ -z "$CONNECTIONS" ]; then
        echo -e "${GREEN}✓ Keine lauschenden Python-Ports gefunden (sicher)${NC}"
        return 0
    else
        echo -e "${RED}⚠ WARNUNG: Python lauscht auf Ports!${NC}"
        echo "$CONNECTIONS"
        return 1
    fi
}

# Funktion: Prüfe ausgehende Verbindungen
check_outbound_connections() {
    echo -e "${YELLOW}[$(date +%H:%M:%S)] Prüfe ausgehende Verbindungen...${NC}"
    
    if command -v netstat &> /dev/null; then
        ESTABLISHED=$(sudo netstat -tnp 2>/dev/null | grep python | grep ESTABLISHED)
    else
        ESTABLISHED=$(sudo ss -tnp 2>/dev/null | grep python | grep ESTAB)
    fi
    
    if [ -z "$ESTABLISHED" ]; then
        echo -e "${GREEN}✓ Keine aktiven Python-Verbindungen${NC}"
    else
        echo -e "${BLUE}ℹ Aktive Verbindungen:${NC}"
        echo "$ESTABLISHED" | while read line; do
            # Extrahiere Ziel-IP/Port
            if [[ $line =~ ([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+):([0-9]+) ]]; then
                IP="${BASH_REMATCH[1]}"
                PORT="${BASH_REMATCH[2]}"
                echo -e "  → ${BLUE}$IP:$PORT${NC}"
            fi
        done
    fi
}

# Funktion: Prüfe Browser-Prozesse
check_browser_processes() {
    echo -e "${YELLOW}[$(date +%H:%M:%S)] Prüfe Browser-Prozesse...${NC}"
    
    BRAVE_COUNT=$(pgrep -c brave || echo 0)
    CHROME_COUNT=$(pgrep -c chrome || echo 0)
    CHROMEDRIVER_COUNT=$(pgrep -c chromedriver || echo 0)
    PYTHON_COUNT=$(pgrep -cf "amazon_invoice_downloader" || echo 0)
    
    echo "  Brave:        $BRAVE_COUNT Prozesse"
    echo "  Chrome:       $CHROME_COUNT Prozesse"
    echo "  ChromeDriver: $CHROMEDRIVER_COUNT Prozesse"
    echo "  Python (DL):  $PYTHON_COUNT Prozesse"
    
    if [ $PYTHON_COUNT -eq 0 ]; then
        echo -e "${YELLOW}⚠ Download-Skript läuft nicht${NC}"
        return 1
    fi
}

# Monitoring-Loop
monitor_loop() {
    echo -e "\n${GREEN}Starte kontinuierliche Überwachung...${NC}"
    echo -e "${YELLOW}Drücke Strg+C zum Beenden${NC}\n"
    
    ALERT_COUNT=0
    
    while true; do
        echo "────────────────────────────────────────────"
        
        # Checks ausführen
        check_python_connections
        LISTENING_STATUS=$?
        
        echo
        check_outbound_connections
        
        echo
        check_browser_processes
        RUNNING_STATUS=$?
        
        # Warnung bei lauschenden Ports
        if [ $LISTENING_STATUS -ne 0 ]; then
            ALERT_COUNT=$((ALERT_COUNT + 1))
            echo -e "\n${RED}🚨 SICHERHEITSWARNUNG: Python lauscht auf Ports! ($ALERT_COUNT)${NC}"
        fi
        
        # Info wenn Skript beendet wurde
        if [ $RUNNING_STATUS -ne 0 ]; then
            echo -e "\n${BLUE}ℹ Download-Skript wurde beendet${NC}"
            echo "Monitor läuft weiter..."
        fi
        
        echo
        sleep 5
    done
}

# Einmalige Prüfung
single_check() {
    check_python_connections
    echo
    check_outbound_connections
    echo
    check_browser_processes
}

# Cleanup-Funktion
cleanup() {
    echo -e "\n\n${YELLOW}Monitor wird beendet...${NC}"
    rm -f "$MONITOR_PID_FILE"
    exit 0
}

trap cleanup SIGINT SIGTERM

# Hauptlogik
case "${1:-monitor}" in
    monitor)
        # Speichere PID
        echo $$ > "$MONITOR_PID_FILE"
        monitor_loop
        ;;
    check)
        single_check
        ;;
    *)
        echo "Usage: $0 [monitor|check]"
        echo "  monitor - Kontinuierliche Überwachung (Standard)"
        echo "  check   - Einmalige Prüfung"
        exit 1
        ;;
esac
